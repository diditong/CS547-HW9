#!/bin/bash
#PBS -l nodes=01:ppn=16:xk
#PBS -l walltime=06:00:00
#PBS -N task2_resnet_tinyimagenet
#PBS -e $PBS_JOBID.err
#PBS -o $PBS_JOBID.out
#PBS -m bea
#PBS -M jtong8@illinois.edu
cd ~/scratch
. /opt/modules/default/init/bash # NEEDED to add module commands to shell
module load bwpy
module load cudatoolkit
aprun -n 1 -N 1 python task2_resnet_tinyimagenet.py