'''
CS547 Deep Learning: Homework 4 Task 2
Author: Jiashuo Tong
Date Submitted: 10/15/2019
'''

import numpy as np
import os
import time
import torch
import torch.utils.data
import torchvision
import torchvision.datasets as datasets
import torchvision.transforms as transforms
import torch.optim as optim
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable

batch_size = 150

transform_train = transforms.Compose([
    transforms.RandomCrop(64, padding=4),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize((0.485,0.456,0.406),(0.229,0.224,0.225)),
])

transform_val = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.485,0.456,0.406),(0.229,0.224,0.225))
])

def create_val_folder(val_dir):
    """
    This method is responsible for separating validation images into separate sub folders
    """
    path = os.path.join(val_dir, 'images')  # path where validation data is present now
    filename = os.path.join(val_dir, 'val_annotations.txt')  # file where image2class mapping is present
    fp = open(filename, "r")  # open file in read mode
    data = fp.readlines()  # read line by line
    # Create a dictionary with image names as key and corresponding classes as values
    val_img_dict = {}
    for line in data:
        words = line.split("\t")
        val_img_dict[words[0]] = words[1]
    fp.close()
    # Create folder if not present, and move image into proper folder
    for img, folder in val_img_dict.items():
        newpath = (os.path.join(path, folder))
        if not os.path.exists(newpath):  # check if folder exists
            os.makedirs(newpath)
        if os.path.exists(os.path.join(path, img)):  # Check if image exists in default directory
            os.rename(os.path.join(path, img), os.path.join(newpath, img))
    return

# Your own directory to the train folder of tiyimagenet
train_dir = './tiny-imagenet-200/train/'
train_dataset = datasets.ImageFolder(train_dir, transform=transform_train)
# To check the index for each classes
# print(train_dataset.class_to_idx)
train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=8)
# Your own directory to the validation folder of tiyimagenet
val_dir = './tiny-imagenet-200/val/'

if 'val_' in os.listdir(val_dir+'images/')[0]:
    create_val_folder(val_dir)
    val_dir = val_dir+'images/'
else:
    val_dir = val_dir+'images/'


val_dataset = datasets.ImageFolder(val_dir, transform=transform_val)
# To check the index for each classes
# print(val_dataset.class_to_idx)
val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=8)


# Construct a Basic Block
class BasicBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1, padding=1):
        super(BasicBlock, self).__init__()
        self.spatial_match = True
        if stride > 1:
            self.spatial_match = False
            self.conv_layer0 = nn.Conv2d(in_channels=in_channels,out_channels=out_channels,kernel_size=1,
                                        stride=stride, padding=0)
        self.conv_layer1 = nn.Conv2d(in_channels=in_channels,out_channels=out_channels,kernel_size=3,
                                     stride=stride,padding=1)
        self.conv_layer2 = nn.Conv2d(in_channels=out_channels,out_channels=out_channels,kernel_size=3,
                                     stride=1,padding=1)
        self.bn_layer1 = nn.BatchNorm2d(out_channels)
        self.bn_layer2 = nn.BatchNorm2d(out_channels)
    def forward(self, X):
        if (self.spatial_match==False):
            R = self.conv_layer0(X)
        else:
            R = X
        X_new = self.conv_layer1(X)
        X_new = F.relu(self.bn_layer1(X_new))
        X_new = self.conv_layer2(X_new)
        X_new = self.bn_layer2(X_new)
        return X_new+R

# Define a 3 by 3 convolution layer
def convolution(in_channels, out_channels, stride=1):
    return nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False)

# Build the basic block structure
class BasicBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1, downsample=None):
        super(BasicBlock, self).__init__()
        self.conv1 = convolution(in_channels, out_channels, stride)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = convolution(out_channels, out_channels)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.downsample = downsample

    def forward(self, x):
        R = x
        X = self.conv1(x)
        X = self.bn1(X)
        X = self.relu(X)
        X = self.conv2(X)
        X = self.bn2(X)
        if self.downsample:
            R = self.downsample(x)
        X += R
        X = self.relu(X)
        return X

# Define the ResNet Network
class ResNet(nn.Module):
    def __init__(self, block, layers, num_classes=200):
        super(ResNet, self).__init__()
        self.in_channels = 32
        self.conv = convolution(3, 32)
        self.bn = nn.BatchNorm2d(32)
        self.dropout = nn.Dropout(p=0.4)
        self.relu = nn.ReLU(inplace=True)
        self.layer1 = self.build_layer(block, 32, layers[0])
        self.layer2 = self.build_layer(block, 64, layers[1], 2)
        self.layer3 = self.build_layer(block, 128, layers[2], 2)
        self.layer4 = self.build_layer(block, 256, layers[3], 2)
        self.max_pool = nn.MaxPool2d(4,stride=4)
        self.fc = nn.Linear(1024, num_classes)
    # Function for building layers with basic blocks
    def build_layer(self, block, out_channels, blocks, stride=1):
        downsample = None
        if (stride != 1) or (self.in_channels != out_channels):
            downsample = nn.Sequential(
                nn.Conv2d(self.in_channels, out_channels, kernel_size=1,
                     stride=stride, bias=False),
                nn.BatchNorm2d(out_channels))
        layers = []
        layers.append(block(self.in_channels, out_channels, stride, downsample))
        self.in_channels = out_channels
        for i in range(1, blocks):
            layers.append(block(out_channels, out_channels))
        return nn.Sequential(*layers)

    def forward(self, x):
        X = self.conv(x)
        X = self.bn(X)
        X = self.relu(X)
        X = self.dropout(X)
        X = self.layer1(X)
        X = self.layer2(X)
        X = self.layer3(X)
        X = self.layer4(X)
        X = self.max_pool(X)
        X = X.view(X.size(0), -1)
        X = self.fc(X)
        return X

model = ResNet(BasicBlock, [2, 4, 4, 2])
#model.load_state_dict(torch.load('parameters_resnet_tiny_2_lr001.ckpt')) # Load a saved model
print ('The structure of the model is:\n', model)
model.cuda() # Send the model to GPU

'''
DEFINING TRAINING HYPERPARAMETERS, LOSS FUNCTION AND OPTIMIZER
'''

num_epochs = 20
learning_rate = 1e-3
loss_function = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=learning_rate)
scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.1)

'''
COMPUTING TEST ACCURACY
'''
def predict():
    accuracy_list = []
    model.eval() # Set the model to evaluation mode which disables the dropout layer
    for batch_idx, (images, labels) in enumerate(val_loader):
        images, labels = Variable(images).cuda(), Variable(labels).cuda()
        output = model(images) # Feed forward
        predictions = output.max(1)[1] # Predictions by the model
        batch_accuracy = float(predictions.eq(labels).sum())/float(batch_size)*100.0 # Compute batch accuracy
        accuracy_list.append(batch_accuracy)
    test_accuracy = np.mean(accuracy_list)
    print('\nAccuracy of predictions on the test set is ', test_accuracy)

'''
TRAINING THE MODEL
'''

start = time.time() # Record the start time
for epoch in range (num_epochs):
    model.train() # Set the model to train mode so dropout layers are functional
    accuracy_list = []
    for batch_idx, (images, labels) in enumerate(train_loader):
        images, labels = Variable(images).cuda(), Variable(labels).cuda() # Send data to GPU
        optimizer.zero_grad() # Zero out the gradients at the beginning of each batch training
        output = model(images) # Feed forward
        loss = loss_function(output,labels) # Compute loss
        loss.backward() # Backward Propagation
        if(epoch>5):
            for group in optimizer.param_groups:
                for p in group['params']:
                    state = optimizer.state[p]
                    if 'step' in state.keys():
                        if(state['step']>=1024):
                            state['step'] = 1000
        optimizer.step() # Update the optimizer
        predictions = output.data.max(1)[1] # Calculate the predictions (indices for maximum output value)
        batch_accuracy = float(predictions.eq(labels.data).sum())/float(batch_size)*100.0 # Compute the training accuracy for each batch
        accuracy_list.append(batch_accuracy)
    epoch_accuracy = np.mean(accuracy_list) # Compute the training accuracy for the current epoch
    scheduler.step()
    end = time.time() # Record the end time
    print("\nEpoch ", epoch+1,"/",num_epochs," is complete in ", end-start, " seconds",
          " with a training accuracy of ", epoch_accuracy) # Print training message for the current epoch
    predict()
    print("\n===================================================================================")

torch.save(model.state_dict(), 'parameters_resnet_tinyimageneti_new.ckpt') # Save the trained model
end = time.time()
print("\nModel is saved. Total time consumed is ", end-start, " seconds")