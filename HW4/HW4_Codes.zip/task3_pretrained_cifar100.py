'''
CS547 Deep Learning: Homework 4 Task 3
Author: Jiashuo Tong
Date Submitted: 10/15/2019
'''

import numpy as np
import os
import time
import torch
import torchvision
import torchvision.datasets as datasets
import torchvision.transforms as transforms
import torch.optim as optim
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import torchvision.models as models
import torch.utils.model_zoo as model_zoo

model_urls = {
    'resnet18': 'https://download.pytorch.org/models/resnet18-5c106cde.pth'
}

def resnet18(pretrained=True) :
    model = torchvision.models.resnet.ResNet(torchvision.models.resnet.BasicBlock, [2, 2, 2, 2])
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['resnet18'], model_dir = './'))
    return model

model = resnet18(pretrained=True)
in_features = model.fc.in_features
model.fc = nn.Linear(in_features, 100)

print("The model structure is ",model)

batch_size = 100

# Resize and normalize CIFAR100 test data
transform_test = transforms.Compose(
    [transforms.Resize(size=(224, 224)),
    transforms.ToTensor(),
     transforms.Normalize((0.5071, 0.4867, 0.4408), (0.2675, 0.2565, 0.2761))])

# Resize, augment and normalize CIFAR100 training data
transform_train = transforms.Compose([transforms.Resize(size=(224, 224)),
                                      transforms.RandomHorizontalFlip(p=0.5),
                                      transforms.ToTensor(),
                                      transforms.Normalize((0.5071, 0.4867, 0.4408), (0.2675, 0.2565, 0.2761))])

# Create DataLoader For Training Data
trainset = torchvision.datasets.CIFAR100(root='',train=True,download=False,
                                         transform=transform_train)
trainloader = torch.utils.data.DataLoader(trainset,batch_size=batch_size,
                                         shuffle=True,num_workers=8)

# Creat DataLoader For Test Data
testset = torchvision.datasets.CIFAR100(root='',train=False,download=False,
                                         transform=transform_test)
testloader = torch.utils.data.DataLoader(testset,batch_size=batch_size,
                                          shuffle=False,num_workers=8)

'''
COMPUTING TEST ACCURACY
'''
def predict():
    accuracy_list = []
    model.eval() # Set the model to evaluation mode which disables the dropout layer
    for batch_idx, (images, labels) in enumerate(testloader):
        images, labels = Variable(images).cuda(), Variable(labels).cuda()
        output = model(images) # Feed forward
        predictions = output.data.max(1)[1] # Predictions by the model
        batch_accuracy = float(predictions.eq(labels.data).sum())/float(batch_size)*100.0 # Compute batch accuracy
        accuracy_list.append(batch_accuracy)
    test_accuracy = np.mean(accuracy_list)
    print('\nAccuracy of predictions on the test set is ', test_accuracy)

'''
DEFINING TRAINING HYPERPARAMETERS, LOSS FUNCTION AND OPTIMIZER
'''
num_epochs = 15
learning_rate = 1e-3
accuracy_list = []
loss_function = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=learning_rate)

'''
TRAINING THE MODEL
'''
model.cuda()
#model.load_state_dict(torch.load('parameters_pretrained_cifar100_lr001.ckpt')) # Load a saved model
start = time.time() # Record the start time
for epoch in range (num_epochs):
    accuracy_list = []
    model.train() # Set the model to train mode so dropout layers are functional
    for batch_idx, (images, labels) in enumerate(trainloader):
        images, labels = Variable(images).cuda(), Variable(labels).cuda() # Send data to GPU
        optimizer.zero_grad() # Zero out the gradients at the beginning of each batch training
        output = model(images) # Feed forward
        loss = loss_function(output,labels) # Compute loss
        loss.backward() # Backward Propagation
        if(epoch>10):
            for group in optimizer.param_groups:
                for p in group['params']:
                    state = optimizer.state[p]
                    if 'step' in state.keys():
                        if(state['step']>=1024):
                            state['step'] = 1000
        optimizer.step() # Update the optimizer
        predictions = output.data.max(1)[1] # Calculate the predictions (indices for maximum output value)
        batch_accuracy = float(predictions.eq(labels.data).sum())/float(batch_size)*100.0 # Compute the training accuracy for each batch
        accuracy_list.append(batch_accuracy)
    epoch_accuracy = np.mean(accuracy_list) # Compute the training accuracy for the current epoch
    end = time.time() # Record the end time
    print("\nEpoch ", epoch+1,"/",num_epochs," is complete in ", end-start, " seconds"," with a training accuracy of ", epoch_accuracy) # Print training message for the current epoch
    predict()
    print("\n===================================================================================")
torch.save(model.state_dict(), 'parameters_pretrained_cifar100_lr001.ckpt') # Save the trained model
end = time.time()
print("\nModel is saved. Total time consumed is ", end-start, " seconds")