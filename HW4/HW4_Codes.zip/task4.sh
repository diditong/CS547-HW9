#!/bin/bash
#PBS -l nodes=02:ppn=16:xk
#PBS -l walltime=06:00:00
#PBS -N task4_sync_sgd_cifar100
#PBS -e $PBS_JOBID.err
#PBS -o $PBS_JOBID.out
#PBS -m bea
#PBS -M jtong8@illinois.edu
cd ~/scratch
. /opt/modules/default/init/bash # NEEDED to add module commands to shell
module load bwpy
module load bwpy-mpi
aprun -n 2 -N 1 python task4_sync_sgd_cifar100.py