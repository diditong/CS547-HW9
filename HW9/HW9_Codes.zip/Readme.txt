About train_sequence_model.py:

1. data_directory = '/projects/training/bayw/hdf5/'
2. Make sure "resnet-50-kinetics.pth" is in the current directory.
3. The following script is used to download the .pth file directly from google drive:

export fileid=18KktApSEhzTeaLfitWRyAaJkxGstrrp2
export filename=resnet-50-kinetics.pth


## WGET ##
wget --save-cookies cookies.txt 'https://docs.google.com/uc?export=download&id='$fileid -O- \
             | sed -rn 's/.*confirm=([0-9A-Za-z_]+).*/\1/p' > confirm.txt

wget --load-cookies cookies.txt -O $filename \
             'https://docs.google.com/uc?export=download&id='$fileid'&confirm='$(<confirm.txt)


About test_sequence_model.py:

1. data_directory = '/projects/training/bayw/hdf5/'
2. For each video, ALL the sequences of it are fed into the model, that is, frames 1-16, 2-17, 3-18, ... (n-15)-n.
3. The first of the two approached from the instructions is adopted because the second approach yields a bad performance.
4. The training time is pretty long, up to around 30 hours.

About test_combined_model.py:

1. data_directory = '/projects/training/bayw/hdf5/'
2. The combined "model" is just an ensemble method, which takes the average of the two predictions from each model as its own prediction.
