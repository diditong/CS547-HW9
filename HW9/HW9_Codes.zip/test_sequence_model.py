import numpy as np
import os
import sys
import time

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
#from torchvision import datasets, transforms
from torch.autograd import Variable
import torch.distributed as dist
import torchvision

from helperFunctions import getUCF101
from helperFunctions import loadSequence
import resnet_3d

import h5py
import cv2

from multiprocessing import Pool

NUM_CLASSES = 101
IMAGE_SIZE = 224

data_directory = '/projects/training/bayw/hdf5/'
class_list, train, test = getUCF101(base_directory = data_directory)

model = torch.load('3d_resnet.model')
print(model)

model.cuda()

### save predictions directory
prediction_directory = 'UCF-101-predictions/'
if not os.path.exists(prediction_directory):
    os.makedirs(prediction_directory)
for label in class_list:
    if not os.path.exists(prediction_directory+label+'/'):
        os.makedirs(prediction_directory+label+'/')

acc_top1 = 0.0
acc_top5 = 0.0
acc_top10 = 0.0
confusion_matrix = np.zeros((NUM_CLASSES,NUM_CLASSES),dtype=np.float32)
random_indices = np.random.permutation(len(test[0]))
mean = np.asarray([0.485, 0.456, 0.406],np.float32)
std = np.asarray([0.229, 0.224, 0.225],np.float32)
model.eval()

for i in range(len(test[0])):

    t1 = time.time()

    index = random_indices[i]

    filename = test[0][index]
    filename = filename.replace('.avi','.hdf5')
    filename = filename.replace('UCF-101','UCF-101-hdf5')

    h = h5py.File(filename,'r')
    
	# Sequences are defined as frames 1-16, 2-17, 3-18, ... (n-15)-n.
    n_frames_per_sequence = 16
    nFrames = len(h['video'])
    nSequences = nFrames-n_frames_per_sequence
	
    # Process each sequence and save the data in the list dataset
    dataset = []
    for j in range(nSequences):
        sequence = h['video'][j:j+n_frames_per_sequence]
        data = []
        for frame in sequence:
            frame = cv2.resize(frame,(IMAGE_SIZE,IMAGE_SIZE))
            frame = frame.astype(np.float32)
            frame = frame/255.0
            frame = (frame - mean)/std
            data.append(frame)
        data = np.asarray(data)
        data = data.transpose(3,0,1,2)
        data = np.expand_dims(data, axis=0)
        dataset.append(data)
    h.close()

    # Compute a prediction vector from each sequence
    prediction = np.zeros((nSequences, NUM_CLASSES), dtype=np.float32)
    for j in range(nSequences):
        with torch.no_grad():
            x = dataset[j]
            x = np.asarray(x,dtype=np.float32)
            x = Variable(torch.FloatTensor(x),requires_grad=False).cuda().contiguous()
            output = model(x)
        prediction[j] = output.cpu().numpy()

    filename = filename.replace(data_directory+'UCF-101-hdf5/',prediction_directory)
    if(not os.path.isfile(filename)):
        with h5py.File(filename,'w') as h:
            h.create_dataset('predictions',data=prediction)

    # Sum up all the prediction vectors. The result is the final prediction of the model.
    for j in range(prediction.shape[0]):
        prediction[j] = np.exp(prediction[j])/np.sum(np.exp(prediction[j]))
    prediction = np.sum(np.log(prediction),axis=0)
	
	# Create a preliminary confusion matrix
    argsort_pred = np.argsort(-prediction)[0:10]
    label = test[1][index]
    confusion_matrix[label,argsort_pred[0]] += 1
    if(label==argsort_pred[0]):
        acc_top1 += 1.0
    if(np.any(argsort_pred[0:5]==label)):
        acc_top5 += 1.0
    if(np.any(argsort_pred[:]==label)):
        acc_top10 += 1.0

    print('i:%d nFrames:%d t:%f (%f,%f,%f)'
          % (i,nFrames,time.time()-t1,acc_top1/(i+1),acc_top5/(i+1), acc_top10/(i+1)))

number_of_examples = np.sum(confusion_matrix,axis=1)
for i in range(NUM_CLASSES):
    confusion_matrix[i,:] = confusion_matrix[i,:]/np.sum(confusion_matrix[i,:])

results = np.diag(confusion_matrix)
indices = np.argsort(results)

sorted_list = np.asarray(class_list)
sorted_list = sorted_list[indices]
sorted_results = results[indices]

for i in range(NUM_CLASSES):
    print(sorted_list[i],sorted_results[i],number_of_examples[indices[i]])

np.save('sequence_confusion_matrix.npy',confusion_matrix)